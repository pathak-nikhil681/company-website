<?php include('../header.php'); ?>
<link href="<?= $base_url ?>/css/style2.css" rel="stylesheet">

<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
  <div class="container text-center py-5">
    <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">
      Progressive Web App Development
    </h3>

    <ol class="breadcrumb justify-content-center text-white mb-0 wow fadeInDown" data-wow-delay="0.3s">
      <li class="breadcrumb-item">
        <a href="index.html" class="text-white">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="service.html" class="text-white">Services</a>
      </li>
      <li class="breadcrumb-item active text-secondary">
        Progressive Web App Development
      </li>
    </ol>
  </div>
</div>
<!-- Header End -->

<!-- Asp.Net E-Commerce Start -->
<div class="container-fluid py-5">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.3s">
        <h5 class="sub-title pe-3">Development</h5>
        <h1 class="display-5 mb-4">Progressive Web App Development</h1>
        <p class="mb-4">
          Our commitment is to empower your business with the latest advancements, including Progressive Web Apps
          (PWAs), fostering continuous growth and expanding your reach.
        </p>
      </div>
      <div class="col-xl-5 wow fadeInRight features" data-wow-delay="0.1s">
        <div class="feature-item text-center p-4">
          <div class="feature-icon p-3 mb-4">
            <img src="../img/pwa.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Asp.Net E-Commerce End -->

<!-- Why Important E-Commerce & CMS Frameworks Start -->
<div class="container-fluid country features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="display-5 mb-4">
      Revolutionising user experience with our expertise in progressive web app development
    </h1>
    <p class="product-p">
      Elevate your digital presence with our Progressive Web App (PWA) development services at TechnoTwist,
      incorporating cutting-edge technologies such as Vue.js and React.js. We take pride in creating web apps that go
      beyond meeting basic expectations. In today's world, users expect more – they want intuitive, visually
      appealing, secure applications that work seamlessly on all devices. At TechnoTwist, our PWA developers excel at
      providing a complete user experience by crafting classic web apps that meet these high standards.
  </div>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-9 col-lg-9 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Features">
        <h3>Seamless connectivity & ultimate engagement with PWA development</h3>
        <span> Unleashing the Power of Responsive Web Design </span>
      </div>
    </div>
    <div class="col-md-3 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
      <div class="row">
        <div class="col-12 text-center mb-3">
          <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
            href="../contact-us.php">Try Services Now</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-5">
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Offline Functionality</h3>
            <p>
              PWAs can work offline, allowing users to access content even
              when they're not connected to the internet. This feature is
              especially valuable for users in areas with intermittent
              connectivity.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-offline-funcationality.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Instant Loading Speed</h3>
            <p>
              PWAs are engineered for efficient loading, ensuring a seamless
              experience even in areas with slow or unreliable internet
              connections. Users experience minimal waiting time when
              accessing PWAs.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-fast-loading-speed.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Push Notifications</h3>
            <p>
              PWAs can send push notifications to users' devices, keeping
              them informed about updates, new content, or personalised
              messages. This feature enhances user engagement and retention.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-customizable-feature.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Access to Device Features</h3>
            <p>
              PWAs can access device features such as the camera,
              geolocation, and sensors. This enables developers to create
              more interactive and feature-rich experiences within the
              browser.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-high-security.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Interface</h3>
            <p>
              PWAs provide an app-like interface, complete with smooth
              animations, gestures, and transitions. Users feel like they
              are interacting with a native app, even though they are using
              a web-based application.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-scalability.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Discoverability and Easy Installation</h3>
            <p>
              PWAs are discoverable through search engines and can be easily
              installed on users' devices. Users can add PWAs to their home
              screens without going through app stores, streamlining the
              installation process.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/web-app-intergration-other.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Why Important E-Commerce & CMS Frameworks End -->

<!-- Benefits Start -->
<div class="container-fluid features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="sub-style">
      <h5 class="sub-title text-primary px-3">Benefits</h5>
    </div>
    <h1 class="display-5 mb-4">
      Innovative Progressive web application Development For Your Business
      Needs
    </h1>
  </div>
  <div class="row g-4 m-5">
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp mb-3" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>01</h4>
        <h4>Offline functionality</h4>
        <p>
          Our PWAs are designed to work offline, providing users with a
          seamless experience even when they are not connected to the
          internet.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>02</h4>
        <h4>Fast loading speed</h4>
        <p>
          Our PWAs are optimised for fast loading speeds, ensuring that
          users can access the app quickly and easily.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>03</h4>
        <h4>Push notifications</h4>
        <p>
          Our PWAs can provide push notifications, allowing users to stay
          informed of important updates and events
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>04</h4>
        <h4>Easy indexing by search engines</h4>
        <p>
          Our PWAs can be easily indexed by search engines, making it easy
          for users to find the app through search results.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>05</h4>
        <h4>Cross-browser compatibility</h4>
        <p>
          Our solutions are designed to work across multiple browsers,
          ensuring that users can access the app regardless of the device
          they are using.
        </p>
      </div>
    </div>
  </div>
</div>
<!-- Benefits End -->

<!-- How We Offer Solutions Start -->
<div class="container-fluid features overflow-hidden py-5 product-title">
  <div class="products offer-solutions">
    <span>Explore service</span>
    <h1 class="">
      Elevate your digital presence with progressive web app development
    </h1>
  </div>
  <h3 class="online-solutions">
    Experience the Best of Mobile and Web with Our Progressive Web App
    Development Services
  </h3>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            In a world full of competition, making things easy for your
            customers is a bold move. Regular efforts may not cut it
            anymore. Progressive Web Apps (PWAs) break free from the
            limitations of traditional mobile apps and websites. They
            combine the strengths of both. We encourage businesses to
            embrace PWAs, meeting the needs of today's tech-savvy users
            while keeping development costs low. At TechnoTwist, we stand out
            as a leading Progressive Web App development company. We focus
            on delivering smooth experiences across all devices and
            providing scalable solutions with the features users love.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            We encourage businesses to embrace PWAs, and at TechnoTwist, we
            are dedicated to helping you succeed in the ever-evolving
            digital landscape. Whether you choose Vue.js, React.js, or other
            technologies, our PWA development ensures your digital presence
            stands out.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- How We Offer Solutions End -->

<!-- Office Project Start -->
<div class="container-fluid training overflow-hidden bg-light py-5">

  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">RECENT WORK</h5>
      </div>
      <h1 class="display-5 mb-4">Some of our favourite projects</h1>

    </div>
    <div class="row g-4">
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-1.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Lords Convent School</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Lords Convent School</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://lordsconventschoolbhilwara/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-2.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Apex Law Services</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Apex Law Services</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://apexlawservices.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-3.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Satguru Travel</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Satguru Travel</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://satgurutravel.tn/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-4.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Sn Publicity</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Sn Publicity</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://snpublicity.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center">
        <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
          href="../portfolio.php">View More</a>
      </div>
    </div>
  </div>
</div>
<!-- Office Project End -->

<!-- Uses technology Start -->
<div>
  <h2 class="center-text">Technologies <span style="color: red;">We Use</span></h2>
  <div class="custom-tabs">
    <input type="radio" id="custom-tab1" name="custom-tab-control" checked>
    <input type="radio" id="custom-tab2" name="custom-tab-control">
    <input type="radio" id="custom-tab3" name="custom-tab-control">
    <input type="radio" id="custom-tab4" name="custom-tab-control">
    <input type="radio" id="custom-tab5" name="custom-tab-control">

    <ul>
      <li title="Frontend">
        <label for="custom-tab1" role="button">
          <h5>Frontend Development</h5>
        </label>
      </li>
      <li title="Backend">
        <label for="custom-tab2" role="button">
          <h5>Backend Development</h5>
        </label>
      </li>
      <li title="Mobile">
        <label for="custom-tab3" role="button">
          <h5>Mobile Development</h5>
        </label>
      </li>
      <li title="Database">
        <label for="custom-tab4" role="button">
          <h5>Database</h5>
        </label>
      </li>
      <li title="CMS">
        <label for="custom-tab5" role="button">
          <h5>CMS</h5>
        </label>
      </li>
    </ul>

    <div class="custom-slider">
      <div class="custom-indicator"></div>
    </div>

    <div class="custom-content">
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/html5.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">HTML5</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/css3.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">CSS3</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/reactjs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ReactJS</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/angular js.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">AngularJS</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/vue.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Vue.js</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/aspnet.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ASP.net</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/netcore.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">.net Core</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/c.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">C#</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/laravel.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Laravel</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/php.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">PHP</h4>
            </div>
          </div>
          <!-- Card 6 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/codeiginter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Codeigniter</h4>
            </div>
          </div>
          <!-- Card 7 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/python.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Python</h4>
            </div>
          </div>
          <!-- Card 8 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/nodejs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Node JS</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/android.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">android</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/ios.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">IOS Development</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/react.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">React Native</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/flutter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Flutter</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/kotlin.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Kotlin</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mssql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MS-SQL</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mysql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MY-SQL</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mongodb.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Mongo DB</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/firebase.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Firebase</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/redis.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Redis</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/wordpress.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Wordpress</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/shopify.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Shopify</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mangento.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Magento</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/strapi.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Strapi</h4>
            </div>
          </div>

        </div>
      </section>
    </div>
  </div>

</div>
<!-- Uses technology End -->

<!--Asked Questions Start -->
<div class="container-fluid service overflow-hidden">
  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">
          Frequently Asked Questions
        </h5>
      </div>
    </div>
    <section class="faq-section">
      <div class="container">
        <!-- FAQ Item 1 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3><span>01</span> What's a Progressive Web App (PWA)?</h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Progressive Web Apps (PWAs) are like those apps you use every
              day. They are built using familiar web technologies like HTML,
              CSS, and JavaScript. Despite being web-based, PWAs deliver the
              same look and functionality as native apps.
            </p>
            <ul>
              <li>
                <b>nderstanding Native Apps:</b> A native app is software
                made specifically for a certain device platform, like iOS
                for iPhones or Android for, well, Android phones.
              </li>
              <li>
                <b>Key Features of PWAs:</b> Now, back to PWAs – they come
                with features such as push notifications and the ability to
                work offline. They also use modern APIs, making it easy to
                add cool features while ensuring reliability. Plus, you can
                install them on any device!
              </li>
              <li>
                <b>Advantages of PWAs:</b> PWAs tap into the vast web
                ecosystem, using plugins, community support, and the ease of
                deploying and maintaining a website. This makes building a
                PWA quick and straightforward.
              </li>
            </ul>

            <p>
              Leverage Shopify's features to create a compelling online
              presence, boost sales, and deliver an outstanding shopping
              experience to your customers.
            </p>
          </div>
        </div>

        <!-- FAQ Item 2 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>02</span> Why Choose TechnoTwist for PWA Development?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <ul>
              <li>
                <b>Enhanced User Engagement:</b> TechnoTwist ensures PWAs
                provide an app-like experience, leading to longer session
                times and increased user interaction compared to traditional
                websites.
              </li>

              <li>
                <b>Cost-Efficiency:</b> Rather than investing in separate
                native apps for different platforms, businesses can opt for
                a single PWA, reducing development and maintenance costs.
              </li>
              <li>
                <b>Offline Accessibility:</b> PWAs by TechnoTwist function
                seamlessly in low or no internet conditions, ensuring users
                can access content and features anytime, enhancing user
                satisfaction.
              </li>
              <li>
                <b>No App Store Hassles: </b>Bypassing app store
                restrictions, fees, and review processes allow faster
                updates and direct user outreach.
              </li>
              <li>
                <b>Improved Discoverability:</b> TechnoTwist's PWAs are
                indexed by search engines, potentially boosting online
                visibility and SEO ranking.
              </li>
              <li>
                <b>Cross-Platform Consistency:</b> PWAs from TechnoTwist work
                across various devices and operating systems, providing a
                consistent user experience that reinforces brand identity.
              </li>
              <li>
                <b>Push Notifications:</b> Businesses benefit from real-time
                updates, promotions, or reminders, fostering better user
                engagement and retention.
              </li>
              <li>
                <b>Safety & Security:</b> TechnoTwist's PWAs are served via
                HTTPS, ensuring secure data exchange, and service workers
                prevent certain types of network attacks.
              </li>
              <li>
                <b>Easy Updates:</b> PWAs developed by TechnoTwist update in
                real-time, ensuring users can always access the latest
                content and features without manual updates.
              </li>
            </ul>

            <p>
              By thinking about these things, you can find a great PWA app
              development company like TechnoTwist that fits your needs and
              provides a superior user experience, making it a smart choice
              for many enterprises.
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Asked Questions End -->

<?php include('../footer.php'); ?>