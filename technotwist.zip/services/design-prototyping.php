<?php include('../header.php'); ?>
<link href="<?= $base_url ?>/css/style2.css" rel="stylesheet">

<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
  <div class="container text-center py-5">
    <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">
      Design Prototyping
    </h3>

    <ol class="breadcrumb justify-content-center text-white mb-0 wow fadeInDown" data-wow-delay="0.3s">
      <li class="breadcrumb-item">
        <a href="index.html" class="text-white">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="service.html" class="text-white">Services</a>
      </li>
      <li class="breadcrumb-item active text-secondary">
        Design Prototyping
      </li>
    </ol>
  </div>
</div>
<!-- Header End -->

<!-- Asp.Net E-Commerce Start -->
<div class="container-fluid py-5">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.3s">
        <h5 class="sub-title pe-3">Development</h5>
        <h1 class="display-5 mb-4">Design Prototyping</h1>
        <p class="mb-4">
          Design prototyping is vital in our product development, providing a blueprint for design and functionality.
          Our skilled designers utilize cutting-edge tools to create refined prototypes, collaborating closely with
          clients to ensure their vision comes to life. Our efficient, cost-effective process ensures the timely
          delivery of high-quality products, marking the intersection of innovation and precision in design.
        </p>
      </div>
      <div class="col-xl-5 wow fadeInRight features" data-wow-delay="0.1s">
        <div class="feature-item text-center p-4">
          <div class="feature-icon p-3 mb-4">
            <img src="../img/Design-Prototyping-01.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Asp.Net E-Commerce End -->

<!-- Why Important E-Commerce & CMS Frameworks Start -->
<div class="container-fluid country features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="display-5 mb-4">
      Transforming Ideas into Interactive Realities with Design Prototyping
    </h1>
    <p class="product-p">
      Design prototyping serves as the bridge between imaginative ideas, often crafted in tools like Figma or Sketch,
      and engaging user experiences. It acts as the connector, turning static design concepts into dynamic, responsive
      prototypes. Beyond just visual appeal, design prototyping is committed to creating prototypes that seamlessly
      adapt to different devices. Whether it's on a desktop or smartphone, the goal is to maintain the essence of the
      design while providing a consistently smooth user experience.
  </div>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-9 col-lg-9 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Features">
        <h3>Advanced features of our design prototyping</h3>
        <span> Innovative Design Prototyping for your business needs </span>
      </div>
    </div>
    <div class="col-md-3 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
      <div class="row">
        <div class="col-12 text-center mb-3">
          <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
            href="../contact-us.php">Try Services Now</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-5">
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Early Validation</h3>
            <p>
              Prototyping allows designers and stakeholders to validate
              design concepts early in the development.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_early.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Improved User Experience</h3>
            <p>
              Prototyping allows designers to test and refine interactions
              and user flows, leading to a more seamless.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_improve.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Fast Time to Market</h3>
            <p>
              By allowing for early testing and validation, design
              prototypes can speed up the development process.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_faster.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Better Collaboration</h3>
            <p>
              Prototyping facilitates collaboration between designers,
              developers, and stakeholders, helping to align everyone.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_better.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Lower Development Costs</h3>
            <p>
              By discovering design issues early and making necessary
              adjustments, design prototypes can help to lower.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_lower.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Early Visualisation</h3>
            <p>
              Allows designers and stakeholders to see a realistic
              representation of the end product.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/des_visible.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Why Important E-Commerce & CMS Frameworks End -->

<!-- Benefits Start -->
<div class="container-fluid features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="sub-style">
      <h5 class="sub-title text-primary px-3">Benefits</h5>
    </div>
    <h1 class="display-5 mb-4">
      Next-Gen Prototyping Designs - Paving a Path to Business Excellence
    </h1>
  </div>
  <div class="row g-4 m-5">
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp mb-3" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>01</h4>
        <h4>Enhanced design visualisation</h4>
        <p>
          Prototyping allows designers to visualise the design and
          experience the interactions, animations, and transitions, leading
          to a better understanding of the design.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>02</h4>
        <h4>Reduced development time</h4>
        <p>
          By validating and refining the design in the prototyping phase,
          development time can be reduced as the final product is closer to
          the intended design.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>03</h4>
        <h4>Better testing and debugging</h4>
        <p>
          Design prototypes can be used to test and debug the product,
          helping to identify and resolve issues before the product is fully
          developed.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>04</h4>
        <h4>Increased design efficiency</h4>
        <p>
          Design prototyping enables designers to work more efficiently and
          effectively, reducing the time and resources needed to complete
          the design process.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>05</h4>
        <h4>Improved stakeholder and user understanding</h4>
        <p>
          Design prototypes can help stakeholders and users better
          understand the product, leading to improved understanding and
          buy-in.
        </p>
      </div>
    </div>
  </div>
</div>
<!-- Benefits End -->

<!-- How We Offer Solutions Start -->
<div class="container-fluid features overflow-hidden py-5 product-title">
  <div class="products offer-solutions">
    <span>Explore service</span>
    <h1 class="">
      Bridge the Gap Between Concept and Reality with Design Prototyping
    </h1>
  </div>
  <h3 class="online-solutions">
    Design Prototyping Services Designed To Lower Your Risk
  </h3>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            Starting to develop software raises many questions, like
            figuring out how the business will benefit or if the application
            will be easy to use. A lot of new entrepreneurs struggle to have
            a clear plan or might have expectations that don't match
            reality. Our goal is to help you deal with these uncertainties
            by guiding you towards a practical vision before you begin
            developing your idea.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            Using our Design Prototyping services, we simplify the Ui/Ux
            elements once your idea is confirmed to be worthwhile. This
            method ensures that you don't spend on unnecessary features, and
            it gives a full view of the project from the beginning to the
            end. Providing a detailed timeline with estimates and essential
            information, this visualisation gives your team a clear vision,
            making a straightforward roadmap for the whole journey of
            developing the minimum viable product.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- How We Offer Solutions End -->

<!-- Office Project Start -->
<div class="container-fluid training overflow-hidden bg-light py-5">

  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">RECENT WORK</h5>
      </div>
      <h1 class="display-5 mb-4">Some of our favourite projects</h1>

    </div>
    <div class="row g-4">
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-1.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Lords Convent School</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Lords Convent School</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://lordsconventschoolbhilwara/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-2.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Apex Law Services</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Apex Law Services</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://apexlawservices.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-3.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Satguru Travel</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Satguru Travel</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://satgurutravel.tn/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-4.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Sn Publicity</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Sn Publicity</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://snpublicity.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center">
        <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
          href="../portfolio.php">View More</a>
      </div>
    </div>
  </div>
</div>
<!-- Office Project End -->

<!-- Uses technology Start -->
<div>
  <h2 class="center-text">Technologies <span style="color: red;">We Use</span></h2>
  <div class="custom-tabs">
    <input type="radio" id="custom-tab1" name="custom-tab-control" checked>
    <input type="radio" id="custom-tab2" name="custom-tab-control">
    <input type="radio" id="custom-tab3" name="custom-tab-control">
    <input type="radio" id="custom-tab4" name="custom-tab-control">
    <input type="radio" id="custom-tab5" name="custom-tab-control">

    <ul>
      <li title="Frontend">
        <label for="custom-tab1" role="button">
          <h5>Frontend Development</h5>
        </label>
      </li>
      <li title="Backend">
        <label for="custom-tab2" role="button">
          <h5>Backend Development</h5>
        </label>
      </li>
      <li title="Mobile">
        <label for="custom-tab3" role="button">
          <h5>Mobile Development</h5>
        </label>
      </li>
      <li title="Database">
        <label for="custom-tab4" role="button">
          <h5>Database</h5>
        </label>
      </li>
      <li title="CMS">
        <label for="custom-tab5" role="button">
          <h5>CMS</h5>
        </label>
      </li>
    </ul>

    <div class="custom-slider">
      <div class="custom-indicator"></div>
    </div>

    <div class="custom-content">
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/html5.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">HTML5</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/css3.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">CSS3</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/reactjs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ReactJS</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/angular js.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">AngularJS</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/vue.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Vue.js</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/aspnet.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ASP.net</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/netcore.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">.net Core</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/c.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">C#</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/laravel.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Laravel</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/php.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">PHP</h4>
            </div>
          </div>
          <!-- Card 6 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/codeiginter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Codeigniter</h4>
            </div>
          </div>
          <!-- Card 7 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/python.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Python</h4>
            </div>
          </div>
          <!-- Card 8 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/nodejs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Node JS</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/android.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">android</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/ios.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">IOS Development</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/react.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">React Native</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/flutter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Flutter</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/kotlin.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Kotlin</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mssql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MS-SQL</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mysql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MY-SQL</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mongodb.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Mongo DB</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/firebase.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Firebase</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/redis.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Redis</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/wordpress.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Wordpress</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/shopify.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Shopify</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mangento.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Magento</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/strapi.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Strapi</h4>
            </div>
          </div>

        </div>
      </section>
    </div>
  </div>

</div>
<!-- Uses technology End -->

<!--Asked Questions Start -->
<div class="container-fluid service overflow-hidden">
  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">
          Frequently Asked Questions
        </h5>
      </div>
    </div>
    <section class="faq-section">
      <div class="container">
        <!-- FAQ Item 1 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>01</span> What are UX prototyping services, and how do
              they contribute to the design process?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              UX prototyping services involve creating interactive models or
              prototypes of a digital product's user interface to simulate
              its functionality and user experience. These services play a
              crucial role in the design process by allowing designers to
              test and refine interactions, ensuring a user-friendly and
              intuitive interface before the actual development phase.
              Through UX prototyping, designers can gather valuable
              feedback, identify potential issues, and enhance the overall
              user experience.
            </p>
          </div>
        </div>

        <!-- FAQ Item 2 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>02</span> How do design and prototyping services work
              together in the development of digital products?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Design and prototyping services work hand in hand to bring
              digital products to life. Design services focus on creating
              visually appealing and functional user interfaces, while
              prototyping services translate these designs into interactive,
              tangible models. The collaboration between design and
              prototyping ensures a seamless transition from concept to
              implementation. Prototypes enable designers to validate design
              concepts, refine interactions, and identify potential
              improvements early in the development process, fostering a
              more efficient and effective design workflow.
            </p>
          </div>
        </div>

        <!-- FAQ Item 3 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>03</span> Why choose TechnoTwist for responsive web design
              services?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <ul>
              <li>
                <b>Low-Fidelity Paper Prototype:</b> It's a quick and
                affordable way to test ideas and make changes instantly.
              </li>
              <li>
                <b>Digital Wireframes:</b> Designers use software like
                Sketch or Adobe XD to create basic visual representations of
                the interface. These wireframes display the layout,
                structure, and content of the design.
              </li>
              <li>
                <b>Interactive Mockups:</b> Tools like InVision or Figma
                allow designers to create interactive prototypes. Users can
                click through screens and experience the flow of the design.
              </li>
              <li>
                <b>High-Fidelity Prototypes:</b> These prototypes closely
                resemble the final product, including detailed visual
                designs, animations, and interactions. They offer a more
                realistic experience for testing and feedback.
              </li>
            </ul>
            <p>
              Real-life examples of prototype designs include mobile apps
              like Instagram, which underwent changes before its launch. The
              automotive industry also uses prototypes to test new vehicle
              models.
            </p>
            <p>
              In summary, prototypes help refine ideas, collect feedback,
              and ensure the final design meets user needs.
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Asked Questions End -->

<?php include('../footer.php'); ?>