<?php include('../header.php'); ?>
<link href="<?= $base_url ?>/css/style2.css" rel="stylesheet">

<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
  <div class="container text-center py-5">
    <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">
      Search Engine Optimization
    </h3>

    <ol class="breadcrumb justify-content-center text-white mb-0 wow fadeInDown" data-wow-delay="0.3s">
      <li class="breadcrumb-item">
        <a href="index.html" class="text-white">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="service.html" class="text-white">Services</a>
      </li>
      <li class="breadcrumb-item active text-secondary">
        Search Engine Optimization
      </li>
    </ol>
  </div>
</div>
<!-- Header End -->

<!-- Asp.Net E-Commerce Start -->
<div class="container-fluid py-5">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.3s">
        <h5 class="sub-title pe-3">Development</h5>
        <h1 class="display-5 mb-4">Search Engine Optimization</h1>
        <p class="mb-4">
          When people want to get information about things, they usually search on the internet. Our strong SEO skills
          ensure that your business appears at the top of search results, making it easy for potential customers to
          find you. Without effective SEO, your other marketing and development efforts may not yield the desired
          results.
        </p>
      </div>
      <div class="col-xl-5 wow fadeInRight features" data-wow-delay="0.1s">
        <div class="feature-item text-center p-4">
          <div class="feature-icon p-3 mb-4">
            <img src="../img/Search-Engine-Optimization.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Asp.Net E-Commerce End -->

<!-- Why Important E-Commerce & CMS Frameworks Start -->
<div class="container-fluid country features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="display-5 mb-4">
      SEO Services to maximise your brand visibility
    </h1>
    <p class="product-p">
      In the online world, being visible is key, and our team of SEO experts is committed to ensuring your brand takes
      the spotlight in search engine results.
  </div>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-9 col-lg-9 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Features">
        <h3>Enhance your website traffic with proven SEO strategies</h3>
        <span> demonstrate the value that your service brings to businesses looking to improve their online presence
          and drive results. </span>
      </div>
    </div>
    <div class="col-md-3 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
      <div class="row">
        <div class="col-12 text-center mb-3">
          <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
            href="../contact-us.php">Try Services Now</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-5">
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Enhanced visibility and traffic</h3>
            <p>
              SEO helps improve your website's ranking on search engine
              results pages (SERPs), making it more visible to potential
              visitors. Higher visibility leads to increased organic
              traffic.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_link.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Cost-Effective marketing</h3>
            <p>
              SEO is a cost-effective digital marketing strategy compared to
              traditional advertising. It targets users actively searching
              for relevant information, ensuring your resources are focused
              on a more receptive audience.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_local.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Credibility and trust</h3>
            <p>
              Websites ranking high in search results are often perceived as
              more credible and trustworthy. SEO helps build authority for
              your brand, fostering trust among users searching for products
              or services.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_technical.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Improved user experience</h3>
            <p>
              SEO involves optimising website elements like page speed,
              mobile responsiveness, and content structure. These
              enhancements improve user experience, keeping visitors engaged
              and reducing bounce rates.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_keyword.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Targeted audience reach</h3>
            <p>
              SEO allows you to tailor your strategies to specific
              demographics, locations, or interests.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_social.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Measurable results and analytics</h3>
            <p>
              SEO tools provide valuable insights into website performance.
              You can track key metrics like traffic, conversion rates, and
              keyword rankings, enabling data-driven decisions to refine
              your SEO strategy continually.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/seo_audit.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Why Important E-Commerce & CMS Frameworks End -->

<!-- Benefits Start -->
<div class="container-fluid features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="sub-style">
      <h5 class="sub-title text-primary px-3">Benefits</h5>
    </div>
    <h1 class="display-5 mb-4">
      Boost your online presence & grow your business
    </h1>
  </div>
  <div class="row g-4 m-5">
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp mb-3" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>01</h4>
        <h4>Boosts your credibility</h4>
        <p>
          A website that ranks high on search engine results pages is
          considered high-quality and trustworthy by search engines. This
          credibility positively affects your business reputation.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>02</h4>
        <h4>Cost-Effective</h4>
        <p>
          Unlike other marketing strategies (such as pay-per-click), SEO
          doesn't have to cost you anything apart from time if you handle it
          yourself. Search engines continuously crawl your site, promoting
          useful content and helping you find new customers organically.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>03</h4>
        <h4>Supports content marketing</h4>
        <p>
          Original content and SEO go hand in hand. By creating helpful
          content (text, images, videos), your site ranks better in search
          results. Optimise your content for relevant keywords and keep it
          fresh to maintain search engine visibility.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>04</h4>
        <h4>Maximises PPC campaigns</h4>
        <p>
          Unpaid (SEO) and paid marketing strategies (PPC) complement each
          other. Having both results appear at the top of search engine
          results pages enhances your brand's credibility.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>05</h4>
        <h4>Targets quality traffic</h4>
        <p>
          SEO is an inbound marketing strategy, making it easy for your
          audience to find you when they actively seek information. Unlike
          traditional outbound advertising, SEO focuses on attracting
          interested users
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>06</h4>
        <h4>Improves user experience</h4>
        <p>
          SEO-optimised sites enhance user experience by improving site
          speed, mobile responsiveness, and overall usability. A positive
          user experience leads to higher engagement and better conversion
          rates.
        </p>
      </div>
    </div>
  </div>
</div>
<!-- Benefits End -->

<!-- How We Offer Solutions Start -->
<div class="container-fluid features overflow-hidden py-5 product-title">
  <div class="products offer-solutions">
    <span>Explore service</span>
    <h1 class="">Achieve better visibility online with SEO excellence</h1>
  </div>
  <h3 class="online-solutions">
    With our strong SEO knowledge, we create strategies that go beyond just
    achieving top results on search engines.
  </h3>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            Our focus is on connecting with the right audience and
            delivering targeted outcomes. We develop tailored SEO marketing
            plans to ensure your business appears prominently whenever
            customers are searching. Starting with a thorough analysis of
            your business and target audience, we optimise keyword trends,
            strengthen your on-site presence, and promote your business
            through effective link-building strategies.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            Partner with our results-driven marketing team to build your
            brand using everything from local SEO to keyword optimization,
            determining the right KPIs, conducting content audits, and
            securing top Google search rankings. Join us in establishing a
            presence that attracts customers actively seeking your products
            or services.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- How We Offer Solutions End -->

<!-- Office Project Start -->
<div class="container-fluid training overflow-hidden bg-light py-5">

  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">RECENT WORK</h5>
      </div>
      <h1 class="display-5 mb-4">Some of our favourite projects</h1>

    </div>
    <div class="row g-4">
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-1.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Lords Convent School</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Lords Convent School</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://lordsconventschoolbhilwara/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-2.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Apex Law Services</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Apex Law Services</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://apexlawservices.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-3.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Satguru Travel</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Satguru Travel</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://satgurutravel.tn/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-4.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Sn Publicity</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Sn Publicity</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://snpublicity.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center">
        <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
          href="../portfolio.php">View More</a>
      </div>
    </div>
  </div>
</div>
<!-- Office Project End -->

<!-- Uses technology Start -->
<div>
  <h2 class="center-text">Technologies <span style="color: red;">We Use</span></h2>
  <div class="custom-tabs">
    <input type="radio" id="custom-tab1" name="custom-tab-control" checked>
    <input type="radio" id="custom-tab2" name="custom-tab-control">
    <input type="radio" id="custom-tab3" name="custom-tab-control">
    <input type="radio" id="custom-tab4" name="custom-tab-control">
    <input type="radio" id="custom-tab5" name="custom-tab-control">

    <ul>
      <li title="Frontend">
        <label for="custom-tab1" role="button">
          <h5>Frontend Development</h5>
        </label>
      </li>
      <li title="Backend">
        <label for="custom-tab2" role="button">
          <h5>Backend Development</h5>
        </label>
      </li>
      <li title="Mobile">
        <label for="custom-tab3" role="button">
          <h5>Mobile Development</h5>
        </label>
      </li>
      <li title="Database">
        <label for="custom-tab4" role="button">
          <h5>Database</h5>
        </label>
      </li>
      <li title="CMS">
        <label for="custom-tab5" role="button">
          <h5>CMS</h5>
        </label>
      </li>
    </ul>

    <div class="custom-slider">
      <div class="custom-indicator"></div>
    </div>

    <div class="custom-content">
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/html5.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">HTML5</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/css3.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">CSS3</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/reactjs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ReactJS</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/angular js.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">AngularJS</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/vue.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Vue.js</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/aspnet.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ASP.net</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/netcore.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">.net Core</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/c.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">C#</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/laravel.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Laravel</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/php.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">PHP</h4>
            </div>
          </div>
          <!-- Card 6 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/codeiginter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Codeigniter</h4>
            </div>
          </div>
          <!-- Card 7 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/python.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Python</h4>
            </div>
          </div>
          <!-- Card 8 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/nodejs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Node JS</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/android.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">android</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/ios.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">IOS Development</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/react.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">React Native</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/flutter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Flutter</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/kotlin.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Kotlin</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mssql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MS-SQL</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mysql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MY-SQL</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mongodb.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Mongo DB</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/firebase.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Firebase</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/redis.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Redis</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/wordpress.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Wordpress</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/shopify.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Shopify</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mangento.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Magento</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/strapi.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Strapi</h4>
            </div>
          </div>

        </div>
      </section>
    </div>
  </div>

</div>
<!-- Uses technology End -->

<!--Asked Questions Start -->
<div class="container-fluid service overflow-hidden">
  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">
          Frequently Asked Questions
        </h5>
      </div>
    </div>
    <section class="faq-section">
      <div class="container">
        <!-- FAQ Item 1 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>01</span> How does SEO help in growing your business?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Search Engine Optimization (SEO) services play a crucial role
              in the digital landscape, helping businesses achieve higher
              online visibility, attract targeted traffic, and ultimately
              foster business growth.
            </p>
            <ul>
              <li>
                <b>Understanding SEO Services:</b> SEO services encompass a
                range of strategies to optimise a website's performance on
                search engines. From creating search engine-friendly titles
                to enhancing site structure and crafting compelling copy,
                SEO services are multifaceted and dynamic.
              </li>
              <li>
                <b>Creating Search Engine-Friendly Content:</b> One
                fundamental aspect of SEO services is creating content that
                resonates with users and search engines. It is crucial to
                include relevant keywords, maintain content relevance, and
                keep titles concise. A search engine-friendly title should
                include 1-2 keywords related to the topic and be kept short.
              </li>
              <li>
                <b>Optimising Website Structure:</b> A well-structured
                website is essential for SEO success. This involves ensuring
                the site is easily navigable, with logical hierarchies and
                relevant internal linking. The ultimate guide to content SEO
                emphasises the importance of site structure in optimising
                content for search engines.
              </li>
              <li>
                <b>Utilising Keywords Effectively:</b> Keywords are the
                foundation of SEO. Finding the right primary keyword that is
                relevant to your content and has a decent search volume is
                crucial. Incorporating these keywords strategically
                throughout your content signals search engines about the
                relevance of your content to user queries.
              </li>
              <li>
                <b>Crafting Actionable Content:</b> SEO writing involves
                action verbs that encourage users to engage with the
                content.
              </li>
              <li>
                <b>Measuring Results and Continuous Improvement:</b> Regular
                analytics and reporting help measure the effectiveness of
                SEO strategies. Businesses can adapt their approach based on
                real-time performance data, ensuring continued search
                rankings and online visibility improvement.
              </li>
              <li>
                <b>Benefits of SEO Services:</b> The advantages of
                implementing SEO services are manifold. Businesses can
                experience increased online visibility, better ranking on
                search engine results pages (SERPs), and higher chances of
                attracting organic traffic. A well-executed SEO strategy can
                also improve brand reputation and long-term business
                success.
              </li>
            </ul>
            <p>
              In summary, SEO services are for businesses wanting to shine
              online and grow steadily. Think of it as fine-tuning your
              content, using smart keywords, and creating a solid online
              presence overall. Every part of SEO, from making your content
              sparkle to choosing the right keywords, helps build a strong
              digital identity. In today's fast-changing digital world,
              using SEO services is not just a good idea; it's a smart
              strategy to make your business stand out.
            </p>
          </div>
        </div>

        <!-- FAQ Item 2 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>02</span> What are the benefits of using the services of
              the best SEO Company?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Choosing the best SEO company for your business comes with
              several advantages. Firstly, you get access to skilled SEO
              experts who know how to make your website show up higher in
              search results.
            </p>

            <p>
              These professionals can do things like finding the right
              keywords, optimising your content, and building strong links
              to increase the number of people visiting your site. They also
              keep an eye on how well your website is doing and give you
              useful information to help you make smart decisions and
              improve your SEO strategies.
            </p>

            <p>
              Hiring SEO experts saves time and resources, allowing you to
              concentrate on your main business tasks. In the end, teaming
              up with a trustworthy SEO company can lead to more potential
              customers, better sales, and overall business growth in the
              online world.
            </p>
          </div>
        </div>
        <!-- FAQ Item 3 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>03</span> How do I choose the right Digital marketing
              agency?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <ul>
              <li>
                <b>Specify Your Objectives:</b> Clearly define your
                marketing goals and what you aim to accomplish with the
                assistance of the agency.
              </li>
              <li>
                <b>Experience and Expertise:</b> Look for agencies with a
                proven track record and relevant industry experience. Check
                their portfolio and client feedback.
              </li>
              <li>
                <b>Services Offered:</b> Confirm that the agency offers the
                exact services you require, including SEO, social media,
                content marketing, PPC, and more.
              </li>
              <li>
                <b>Strategy and Approach:</b> Inquire about their marketing
                strategies and how they plan to achieve your goals. Ensure
                their approach aligns with your business values.
              </li>
              <li>
                <b>Transparency and Communication:</b> Choose an agency that
                maintains open communication and keeps you informed about
                progress and results.
              </li>
              <li>
                <b>Budget and ROI:</b> Consider your budget and evaluate the
                potential return on investment. A good agency will be
                transparent about costs and value delivered.
              </li>
              <li>
                <b>Industry Insights:</b> Look for agencies that stay
                updated with the latest industry trends and use data-driven
                insights.
              </li>
              <li>
                <b>Personal Connection:</b> Arrange a meeting or call with
                the agency team to understand their approach and determine
                if there's a good fit.
              </li>
              <li>
                <b>Client Reviews and References:</b> Check online reviews
                and ask for references from past or current clients to gain
                insight into their work ethics.
              </li>
              <li>
                <b>Contract and Flexibility:</b> Review the agency's
                contract terms and ensure they provide flexibility in case
                your needs change over time.
              </li>
            </ul>

            <p>
              By carefully evaluating and comparing digital marketing
              agencies based on these factors, you can choose a reliable and
              competent partner like TechnoTwist to boost your online success
              and business growth.
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Asked Questions End -->

<?php include('../footer.php'); ?>