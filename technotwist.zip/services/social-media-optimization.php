<?php include('../header.php'); ?>
<link href="<?= $base_url ?>/css/style2.css" rel="stylesheet">

<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
  <div class="container text-center py-5">
    <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">
      Social Media Optimization
    </h3>

    <ol class="breadcrumb justify-content-center text-white mb-0 wow fadeInDown" data-wow-delay="0.3s">
      <li class="breadcrumb-item">
        <a href="index.html" class="text-white">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="service.html" class="text-white">Services</a>
      </li>
      <li class="breadcrumb-item active text-secondary">
        Social Media Optimization
      </li>
    </ol>
  </div>
</div>
<!-- Header End -->

<!-- Asp.Net E-Commerce Start -->
<div class="container-fluid py-5">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.3s">
        <h5 class="sub-title pe-3">Development</h5>
        <h1 class="display-5 mb-4">Social Media Optimization</h1>
        <p class="mb-4">
          Elevate your brand's visibility and engagement on various platforms with our Social Media Optimization
          services as we tailor strategies to maximise reach and impact.
        </p>
      </div>
      <div class="col-xl-5 wow fadeInRight features" data-wow-delay="0.1s">
        <div class="feature-item text-center p-4">
          <div class="feature-icon p-3 mb-4">
            <img src="../img/Social-Media-Optimization.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Asp.Net E-Commerce End -->

<!-- Why Important E-Commerce & CMS Frameworks Start -->
<div class="container-fluid country features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="display-5 mb-4">
      Crafting success beyond likes with strategic SMO solutions
    </h1>
    <p class="product-p">
      We specialise in creating, connecting, and conversing with both traditional and unique ideas to solidify your
      brand across social channels. Our standout social campaigns and creative strategies set brands apart from the
      usual noise. Let's redefine your brand's presence with our effective social media marketing services.
  </div>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-9 col-lg-9 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Features">
        <h3>Ignite, Interact & Innovate Brands through SMO Excellence!</h3>
        <span> Unleashing Potential in Every Social Moment with SMO Brilliance! </span>
      </div>
    </div>
    <div class="col-md-3 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
      <div class="row">
        <div class="col-12 text-center mb-3">
          <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
            href="../contact-us.php">Try Services Now</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-5">
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Building a Brand</h3>
            <p>
              Establishing a successful brand requires consistent effort.
              SMO services help create, grow, and manage a brand's online
              presence from the outset.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_community.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Cost Reduction</h3>
            <p>
              Time is money in business. Maintaining an online presence is
              crucial for selling products and running your business
              effectively.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_content.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>SEM</h3>
            <p>
              High rankings on search engines are essential for showcasing
              your products or services. SMO contributes to a robust online
              presence, helping you climb higher in search engine rankings
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_social.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds overflow-hidden">
            <h3>Advertisement and Reputation Management</h3>
            <p>
              Social media can swiftly build or destroy a brand. A good SMO
              service acts as an advertising agency for your brand. It helps
              create, market, and maintain a positive brand image, ensuring
              your reputation remains intact.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_audience.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Increased Traffic</h3>
            <p>
              SMO is a significant source of website traffic. Besides search
              engines and email marketing, social media drives visitors to
              your site. Effective SMO strategies attract users, leading to
              increased visibility and engagement.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_social1.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds overflow-hidden">
            <h3>Quick Awareness and Connectivity</h3>
            <p>
              SMO rapidly spreads awareness about your brand, products, and
              services through social networking sites. It facilitates
              direct communication with customers, fostering better
              connections and driving business growth.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/smo_platform.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Why Important E-Commerce & CMS Frameworks End -->

<!-- Benefits Start -->
<div class="container-fluid features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="sub-style">
      <h5 class="sub-title text-primary px-3">Benefits</h5>
    </div>
    <h1 class="display-5 mb-4">
      SMO empowered to elevate your brand's digital resonance
    </h1>
  </div>
  <div class="row g-4 m-5">
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp mb-3" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>01</h4>
        <h4>Increased Brand Visibility</h4>
        <p>
          SMO expands your brand's reach across social platforms, making it
          more visible to potential customers.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>02</h4>
        <h4>Targeted Audience Engagement</h4>
        <p>
          Engage directly with your audience through SMO strategies,
          fostering trust and loyalty.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>03</h4>
        <h4>Improved Website Traffic</h4>
        <p>
          Effective SMO drives traffic to your website, enhancing user
          engagement and conversions.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>04</h4>
        <h4>Positive Reputation Management</h4>
        <p>
          Monitor feedback promptly, maintaining a positive brand
          perception.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>05</h4>
        <h4>CostEffective Marketing</h4>
        <p>
          Outsourcing SMO services is often more cost-effective than
          handling them in-house.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>06</h4>
        <h4>SEO Synergy</h4>
        <p>SMO complements SEO efforts, boosting search engine rankings.</p>
      </div>
    </div>
  </div>
</div>
<!-- Benefits End -->

<!-- How We Offer Solutions Start -->
<div class="container-fluid features overflow-hidden py-5 product-title">
  <div class="products offer-solutions">
    <span>Explore service</span>
    <h1 class="">
      Supercharge your presence in the social realm with our SMO services
    </h1>
  </div>
  <h3 class="online-solutions">
    SMO involves various strategies and techniques designed to make the most
    of social media channels and increase engagement, visibility, and the
    overall impact of a social media presence.
  </h3>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            In today's dynamic digital marketing arena, Social Media
            Optimization (SMO) stands as a cornerstone for both businesses
            and individuals. Its significance lies in the ability to harness
            the potential of social media platforms strategically. SMO
            enables entities to not only enhance brand awareness but also
            forge meaningful connections with their target audience. By
            seamlessly integrating with various platforms, SMO becomes a
            powerful tool for driving substantial website traffic and
            achieving diverse marketing objectives.
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            As a vital component of the digital toolkit, SMO empowers
            businesses and individuals to navigate the ever-evolving social
            media landscape. Its multifaceted approach facilitates the
            creation of a vibrant online presence, fostering engagement, and
            propelling growth. Through strategic optimization, SMO ensures
            that brands and individuals alike can make a lasting impact in
            the digital sphere, influencing conversations and establishing a
            strong foothold in their respective niches.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- How We Offer Solutions End -->

<!-- Office Project Start -->
<div class="container-fluid training overflow-hidden bg-light py-5">

  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">RECENT WORK</h5>
      </div>
      <h1 class="display-5 mb-4">Some of our favourite projects</h1>

    </div>
    <div class="row g-4">
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-1.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Lords Convent School</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Lords Convent School</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://lordsconventschoolbhilwara/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-2.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Apex Law Services</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Apex Law Services</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://apexlawservices.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-3.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Satguru Travel</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Satguru Travel</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://satgurutravel.tn/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-4.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Sn Publicity</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Sn Publicity</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://snpublicity.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center">
        <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
          href="../portfolio.php">View More</a>
      </div>
    </div>
  </div>
</div>
<!-- Office Project End -->

<!-- Uses technology Start -->
<div>
  <h2 class="center-text">Technologies <span style="color: red;">We Use</span></h2>
  <div class="custom-tabs">
    <input type="radio" id="custom-tab1" name="custom-tab-control" checked>
    <input type="radio" id="custom-tab2" name="custom-tab-control">
    <input type="radio" id="custom-tab3" name="custom-tab-control">
    <input type="radio" id="custom-tab4" name="custom-tab-control">
    <input type="radio" id="custom-tab5" name="custom-tab-control">

    <ul>
      <li title="Frontend">
        <label for="custom-tab1" role="button">
          <h5>Frontend Development</h5>
        </label>
      </li>
      <li title="Backend">
        <label for="custom-tab2" role="button">
          <h5>Backend Development</h5>
        </label>
      </li>
      <li title="Mobile">
        <label for="custom-tab3" role="button">
          <h5>Mobile Development</h5>
        </label>
      </li>
      <li title="Database">
        <label for="custom-tab4" role="button">
          <h5>Database</h5>
        </label>
      </li>
      <li title="CMS">
        <label for="custom-tab5" role="button">
          <h5>CMS</h5>
        </label>
      </li>
    </ul>

    <div class="custom-slider">
      <div class="custom-indicator"></div>
    </div>

    <div class="custom-content">
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/html5.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">HTML5</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/css3.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">CSS3</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/reactjs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ReactJS</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/angular js.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">AngularJS</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/vue.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Vue.js</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/aspnet.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ASP.net</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/netcore.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">.net Core</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/c.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">C#</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/laravel.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Laravel</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/php.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">PHP</h4>
            </div>
          </div>
          <!-- Card 6 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/codeiginter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Codeigniter</h4>
            </div>
          </div>
          <!-- Card 7 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/python.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Python</h4>
            </div>
          </div>
          <!-- Card 8 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/nodejs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Node JS</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/android.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">android</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/ios.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">IOS Development</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/react.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">React Native</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/flutter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Flutter</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/kotlin.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Kotlin</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mssql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MS-SQL</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mysql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MY-SQL</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mongodb.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Mongo DB</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/firebase.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Firebase</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/redis.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Redis</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/wordpress.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Wordpress</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/shopify.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Shopify</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mangento.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Magento</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/strapi.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Strapi</h4>
            </div>
          </div>

        </div>
      </section>
    </div>
  </div>

</div>
<!-- Uses technology End -->

<!--Asked Questions Start -->
<div class="container-fluid service overflow-hidden">
  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">
          Frequently Asked Questions
        </h5>
      </div>
    </div>
    <section class="faq-section">
      <div class="container">
        <!-- FAQ Item 1 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>01</span> What is a Social Media Marketing Service?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              A Social Media Marketing Service (SMM) refers to the use of
              social media platforms as strategic tools for marketing and
              promotion. It involves interacting with customers on platforms
              like Facebook, Instagram, Twitter, and LinkedIn to build brand
              awareness, foster engagement, increase sales, and drive
              website traffic. SMM utilises various tactics, including
              creating and sharing content, running targeted advertising
              campaigns, and engaging with the audience through comments and
              messages. The goal is to enhance the brand's online presence,
              connect with the target audience, and ultimately achieve
              marketing objectives
            </p>
          </div>
        </div>

        <!-- FAQ Item 2 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3><span>02</span> What is SEO and SMO?</h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <ul>
              <li>
                <b>SEO (Search Engine Optimization):</b> SEO is the practice
                of optimising a website to rank higher in search engine
                results for specific keywords. It involves various
                techniques such as keyword optimization, creating quality
                content, improving website structure, and obtaining
                backlinks. The primary goal of SEO is to increase organic
                (non-paid) traffic to a website by improving its visibility
                on search engines like Google.
              </li>
              <li>
                <b>SMO (Social Media Optimisation):</b> It involves
                strategies to optimise social media profiles, create
                shareable content, and engage with the audience. The goal of
                SMO is to increase brand awareness, drive traffic from
                social media channels, and foster a positive brand image.
                SMO emphasises leveraging social media platforms like
                Facebook, Instagram, Twitter, and LinkedIn to connect with
                the target audience and build a strong online community.
              </li>
            </ul>
          </div>
        </div>
        <!-- FAQ Item 3 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3><span>03</span> Which is Better: SEO or SMO?</h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              The effectiveness of SEO (Search Engine Optimisation) and SMO
              (Social Media Optimisation) depends on the goals and nature of
              your business.
            </p>

            <p>SEO is Better When:</p>
            <ul>
              <li>
                <b>Search Engine Visibility Matters:</b> If your primary
                goal is to rank higher on search engine results pages
                (SERPs) and attract organic traffic, SEO is crucial.
              </li>
              <li>
                <b>Content Focus:</b> When your strategy revolves around
                creating high-quality, keyword-optimised content to address
                user queries and needs.
              </li>
              <li>
                <b>Long-Term Strategy:</b> SEO is a long-term investment
                that builds a sustainable online presence over time.
              </li>
            </ul>
            <p>SMO is Better When:</p>
            <ul>
              <li>
                <b>Brand Engagement is Keys:</b> If building a community,
                engaging with the audience, and creating a strong brand
                presence on social media platforms are priorities.
              </li>
              <li>
                <b>Viral Content:</b> When your content is designed for
                sharing, likes, and comments, SMO can amplify its reach
                through social networks.
              </li>
              <li>
                <b>Quick Visibility:</b> SMO can generate faster results in
                terms of visibility and interaction on social media
                platforms compared to the gradual growth of SEO.
              </li>
              <li>
                <b>The Ideal Approach:</b> In reality, a holistic digital
                marketing strategy often incorporates both SEO and SMO. They
                complement each other, with SEO driving organic traffic from
                search engines, and SMO enhancing brand visibility,
                engagement, and community-building on social media. The
                choice between SEO and SMO should align with your business
                objectives and the dynamics of your target audience.
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Asked Questions End -->

<?php include('../footer.php'); ?>