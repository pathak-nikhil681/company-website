<?php include('../header.php'); ?>
<link href="<?= $base_url ?>/css/style2.css" rel="stylesheet">
<!-- Header Start -->
<div class="container-fluid bg-breadcrumb">
  <div class="container text-center py-5">
    <h3 class="text-white display-3 mb-4 wow fadeInDown" data-wow-delay="0.1s">
      ASP.NET Development
    </h3>

    <ol class="breadcrumb justify-content-center text-white mb-0 wow fadeInDown" data-wow-delay="0.3s">
      <li class="breadcrumb-item">
        <a href="index.html" class="text-white">Home</a>
      </li>
      <li class="breadcrumb-item">
        <a href="service.html" class="text-white">Services</a>
      </li>
      <li class="breadcrumb-item active text-secondary">
        ASP.NET Development
      </li>
    </ol>
  </div>
</div>
<!-- Header End -->

<!-- Asp.Net E-Commerce Start -->
<div class="container-fluid py-5">
  <div class="container py-5">
    <div class="row g-5">
      <div class="col-xl-7 wow fadeInLeft" data-wow-delay="0.3s">
        <h5 class="sub-title pe-3">Development</h5>
        <h1 class="display-5 mb-4">ASP.NET Development</h1>
        <p class="mb-4">
          At TechnoTwist, we specialise in delivering top-notch Asp.Net development solutions. Our expertise extends
          to
          converting PSD designs into dynamic and responsive Asp.Net applications, ensuring seamless functionality and
          an engaging user experience.
        </p>
      </div>
      <div class="col-xl-5 wow fadeInRight features" data-wow-delay="0.1s">
        <div class="feature-item text-center p-4">
          <div class="feature-icon p-3 mb-4">
            <img src="../img/ASP2.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Asp.Net E-Commerce End -->

<!-- Why Important E-Commerce & CMS Frameworks Start -->
<div class="container-fluid country features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <h1 class="display-5 mb-4">
      Crafting ideas into reality with expert Asp.Net development services
    </h1>
    <p class="product-p">
      Our team excels in ASP.NET development, mastering every facet from basics to advanced features. We stay updated
      on the latest trends, integrating new tools for top-notch solutions. Dedicated to mastering ASP.NET's
      foundational components, our team actively embraces new tools and best practices to ensure cutting-edge
      solutions for your business objectives.
  </div>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-9 col-lg-9 col-xl-9 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Features">
        <h3>The advanced features of Asp.Net development</h3>
        <span> from idea to successful project completion. </span>
      </div>
    </div>
    <div class="col-md-3 col-lg-3 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
      <div class="row">
        <div class="col-12 text-center mb-3">
          <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
            href="../contact-us.php">Try Services Now</a>
        </div>
      </div>
    </div>
    <div class="row g-4 mt-5">
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Cross-Platform Support</h3>
            <p>
              Asp.Net runs on Windows, macOS, and Linux, providing
              flexibility to deploy applications on multiple platforms.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/asp_mobile.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Robust Security</h3>
            <p>
              Built-in security features such as authentication,
              authorization, and encryption ensure that applications.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/html-secure.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Scalability</h3>
            <p>
              Asp.Net applications can be easily scaled to meet growing
              traffic and processing demands.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/asp_social.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item mb-5">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Tooling and Integration</h3>
            <p>
              Asp.Net integrates with various development tools and
              technologies, such as Visual Studio and SQL Server.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/flutter_4.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>Modular Design</h3>
            <p>
              Asp.Net uses a modular design, allowing developers to choose
              only the components.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/asp_modular.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
      <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
        <div class="country-item">
          <div class="roundeds WooCommerce overflow-hidden">
            <h3>High Performance</h3>
            <p>
              Asp.Net applications are optimised for performance, delivering
              fast and responsive user experiences.
            </p>
          </div>
          <div class="country-flag justify-content-center text-center">
            <img src="../img/asp_high.png" class="img-fluid" alt="Image" />
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Why Important E-Commerce & CMS Frameworks End -->

<!-- Benefits Start -->
<div class="container-fluid features overflow-hidden py-5">
  <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
    <div class="sub-style">
      <h5 class="sub-title text-primary px-3">Benefits</h5>
    </div>
    <h1 class="display-5 mb-4">
      Innovative Asp.Net development for your business needs
    </h1>
  </div>
  <div class="row g-4 m-5">
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp mb-3" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>01</h4>
        <h4>Open-source</h4>
        <p>
          NET Core is an open-source platform, meaning its source code is
          freely available to anyone to use, modify, or distribute. This
          allows for greater collaboration and community involvement in its
          development and improvement.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>02</h4>
        <h4>Cloud-ready</h4>
        <p>
          .NET Core is optimized for cloud deployment, making it a popular
          choice for cloud-based web applications and services. It can be
          deployed to various cloud platforms, such as Microsoft Azure,
          Amazon Web Services, and Google Cloud Platform.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>03</h4>
        <h4>Strong tooling</h4>
        <p>
          .NET Core comes with a suite of tools, including a robust
          command-line interface, integrated development environment (IDE)
          extensions, and powerful libraries, making it easier to develop,
          test, and deploy applications.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>04</h4>
        <h4>Future-proof</h4>
        <p>
          .NET Core is the future of the .NET platform and is constantly
          being updated with new features and improvements, ensuring it
          remains a viable platform for the long term.
        </p>
      </div>
    </div>
    <div class="col-md-4 col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.1s">
      <div class="Benefits">
        <h4>05</h4>
        <h4>Improved security</h4>
        <p>
          .NET Core has built-in security features and follows modern
          security best practices, helping to protect sensitive data and
          reducing the risk of security breaches. Additionally, the
          open-source nature of the platform allows for community-driven
          security improvements and bug fixes.
        </p>
      </div>
    </div>
  </div>
</div>
<!-- Benefits End -->

<!-- How We Offer Solutions Start -->
<div class="container-fluid features overflow-hidden py-5 product-title">
  <div class="products offer-solutions">
    <span>Explore service</span>
    <h1 class="">
      Transform mobile & web experience with expert Asp.Net development
    </h1>
  </div>
  <h3 class="online-solutions">
    Our development approach is comprehensive and collaborative
  </h3>
  <div class="row g-4 product-title product-btn">
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            With expertise in ASP.NET development, we create robust,
            user-friendly applications that elevate your business. Our focus
            on customization ensures your digital presence aligns with your
            brand identity and delivers an exceptional user experience. Our
            versatile ASP.NET development team crafts solutions tailored to
            your unique business needs across various industry sectors
          </p>
        </div>
      </div>
    </div>
    <div class="col-md-6 col-lg-6 col-xl-6 wow fadeInUp" data-wow-delay="0.1s">
      <div class="product-display">
        <div class="product-content">
          <p id="display-description">
            Whether you're a startup making your mark or an established
            enterprise expanding your digital footprint, our tailored
            ASP.NET development services cater to diverse industries, from
            e-commerce to healthcare.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- How We Offer Solutions End -->

<!-- Office Project Start -->
<div class="container-fluid training overflow-hidden bg-light py-5">

  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">RECENT WORK</h5>
      </div>
      <h1 class="display-5 mb-4">Some of our favourite projects</h1>

    </div>
    <div class="row g-4">
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-1.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Lords Convent School</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Lords Convent School</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://lordsconventschoolbhilwara/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.3s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-2.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Apex Law Services</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Apex Law Services</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://apexlawservices.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.5s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-3.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Satguru Travel</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Satguru Travel</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://satgurutravel.tn/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-lg-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.7s">
        <div class="training-item">
          <div class="training-inner">
            <img src="../img/training-4.jpg" class="img-fluid w-100 rounded" alt="Image">
            <div class="training-title-name">
              <a class="h4 text-white mb-0">Sn Publicity</a>
            </div>
          </div>
          <div class="training-content bg-secondary rounded-bottom p-4">
            <h4 class="text-white">Sn Publicity</h4>
            <p class="text-white-50">Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem,
              veritatis.</p>
            <a class="btn btn-secondary rounded-pill text-white p-0" href="https://snpublicity.com/"
              target="_blank">Read More <i class="fa fa-arrow-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-12 text-center">
        <a class="btn btn-primary border-secondary rounded-pill py-3 px-5 wow fadeInUp" data-wow-delay="0.1s"
          href="../portfolio.php">View More</a>
      </div>
    </div>
  </div>
</div>
<!-- Office Project End -->

<!-- Uses technology Start -->
<div>
  <h2 class="center-text">Technologies <span style="color: red;">We Use</span></h2>
  <div class="custom-tabs">
    <input type="radio" id="custom-tab1" name="custom-tab-control" checked>
    <input type="radio" id="custom-tab2" name="custom-tab-control">
    <input type="radio" id="custom-tab3" name="custom-tab-control">
    <input type="radio" id="custom-tab4" name="custom-tab-control">
    <input type="radio" id="custom-tab5" name="custom-tab-control">

    <ul>
      <li title="Frontend">
        <label for="custom-tab1" role="button">
          <h5>Frontend Development</h5>
        </label>
      </li>
      <li title="Backend">
        <label for="custom-tab2" role="button">
          <h5>Backend Development</h5>
        </label>
      </li>
      <li title="Mobile">
        <label for="custom-tab3" role="button">
          <h5>Mobile Development</h5>
        </label>
      </li>
      <li title="Database">
        <label for="custom-tab4" role="button">
          <h5>Database</h5>
        </label>
      </li>
      <li title="CMS">
        <label for="custom-tab5" role="button">
          <h5>CMS</h5>
        </label>
      </li>
    </ul>

    <div class="custom-slider">
      <div class="custom-indicator"></div>
    </div>

    <div class="custom-content">
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/html5.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">HTML5</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/css3.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">CSS3</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/reactjs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ReactJS</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/angular js.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">AngularJS</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/vue.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Vue.js</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/aspnet.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">ASP.net</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/netcore.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">.net Core</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/c.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">C#</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/laravel.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Laravel</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/php.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">PHP</h4>
            </div>
          </div>
          <!-- Card 6 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/codeiginter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Codeigniter</h4>
            </div>
          </div>
          <!-- Card 7 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/python.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Python</h4>
            </div>
          </div>
          <!-- Card 8 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/nodejs.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Node JS</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/android.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">android</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/ios.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">IOS Development</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/react.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">React Native</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/flutter.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Flutter</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/kotlin.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Kotlin</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mssql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MS-SQL</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mysql.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">MY-SQL</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mongodb.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Mongo DB</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/firebase.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Firebase</h4>
            </div>
          </div>
          <!-- Card 5 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/redis.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Redis</h4>
            </div>
          </div>
        </div>
      </section>
      <section>
        <div class="row">
          <!-- Card 1 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/wordpress.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Wordpress</h4>
            </div>
          </div>
          <!-- Card 2 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/shopify.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Shopify</h4>
            </div>
          </div>
          <!-- Card 3 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/mangento.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Magento</h4>
            </div>
          </div>
          <!-- Card 4 -->
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="custom-card p-4 text-center">
              <div class="card-icon mb-3">
                <img src="../img/strapi.png" alt="HTML Icon" style="width: 50px; height: auto;">
              </div>
              <h4 class="mb-3">Strapi</h4>
            </div>
          </div>

        </div>
      </section>
    </div>
  </div>

</div>
<!-- Uses technology End -->

<!--Asked Questions Start -->
<div class="container-fluid service overflow-hidden">
  <div class="container py-5">
    <div class="section-title text-center mb-5 wow fadeInUp" data-wow-delay="0.1s">
      <div class="sub-style">
        <h5 class="sub-title text-primary px-3">
          Frequently Asked Questions
        </h5>
      </div>
    </div>
    <section class="faq-section">
      <div class="container">
        <!-- FAQ Item 1 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>01</span> How much does it cost to make a good Asp.Net
              web application?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              The price depends on things like how complicated the project
              is, how many features you want, and how much you want it to be
              customised. At TechnoTwist, we know that every project is
              different, so we figure out the cost based on what you need.
              Usually, making a reliable Asp.Net web app can cost anywhere
              from $10,000 to $200,000 or more.
            </p>

            <p>
              The actual cost might be different based on your project
              details. We make sure to give you a fair price without
              compromising on quality. Our team of skilled Asp.Net
              developers makes sure your web app is not just reliable but
              also scalable, safe, and works really well.
            </p>
          </div>
        </div>

        <!-- FAQ Item 2 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>02</span> Searching for a reliable Asp.Net web app
              development company for your projects?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              If you're searching for the best Asp.Net web app development
              company for your projects, TechnoTwist is the best choice. With
              our extensive experience and proficiency in Asp.Net
              development, we have established a strong reputation in the
              industry. Our team of skilled .Net developers is well-versed
              in the latest technologies and frameworks, ensuring that your
              web applications are cutting-edge and customised to your
              specific business needs.
            </p>

            <p>
              Whether you're a startup, a small business, or a large
              corporation, we provide comprehensive .Net application
              development services. Our proven track record of delivering
              successful projects serves as validation of our expertise.
              Having collaborated with clients across various industries, we
              specialise in delivering dynamic and powerful digital
              products.
            </p>
          </div>
        </div>

        <!-- FAQ Item 3 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>03</span> How is TechnoTwist different from other
              companies?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              At TechnoTwist, what sets us apart is our strong commitment to
              excellence and innovation. Our team of highly skilled
              Microsoft Certified Professionals goes the extra mile to
              understand your specific business needs, delivering customised
              solutions that go beyond expectations. We prioritise your
              satisfaction with a customer-centric approach. Our extensive
              experience across various technologies and industries brings a
              fresh and creative perspective to every project. Through
              effective communication and seamless project management, we
              ensure timely delivery and successful outcomes.
            </p>
            <p>
              Remaining current with the latest industry trends and
              technologies, we offer cutting-edge solutions that provide a
              competitive edge. Choose TechnoTwist for your next project and
              witness the difference firsthand.
            </p>
          </div>
        </div>
        <!-- FAQ Item 4 -->
        <div class="faq-item">
          <div class="faq-question">
            <h3>
              <span>04</span> What are the key considerations for businesses
              when choosing between Asp.Net and PHP?
            </h3>
            <span class="faq-toggle">+</span>
          </div>
          <div class="faq-answer">
            <p>
              Certainly! Both Asp.Net and PHP continue to be widely used in
              the web development industry, with each having its own set of
              advantages. Asp.Net, developed by Microsoft, is particularly
              favoured by large enterprises for its robustness, scalability,
              and seamless integration with Microsoft technologies. It's
              commonly employed in sectors such as banking, finance,
              insurance, healthcare, and logistics due to its comprehensive
              development environment and strong security features.
            </p>

            <p>
              On the other hand, PHP is appreciated for its simplicity,
              flexibility, and support of a large developer community,
              making it a popular choice for smaller businesses and
              individual developers.
            </p>
            <p>
              The decision to use Asp.Net or PHP depends on factors such as
              project requirements, technical expertise, budget, and the
              desired ecosystem. It's crucial to evaluate these aspects to
              determine which technology aligns best with your specific
              needs.
            </p>
          </div>
        </div>
      </div>
    </section>
  </div>
</div>
<!-- Asked Questions End -->

<?php include('../footer.php');?>